package com.conceptdesignarchitect.laporanku.models

import com.google.gson.annotations.SerializedName

data class DataSubpekerjaanItem(

	@field:SerializedName("pekerjaan")
	val pekerjaan: String? = null
)