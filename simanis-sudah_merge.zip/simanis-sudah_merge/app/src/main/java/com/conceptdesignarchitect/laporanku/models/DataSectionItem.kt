package com.conceptdesignarchitect.laporanku.models

import com.google.gson.annotations.SerializedName

data class DataSectionItem(

	@field:SerializedName("section")
	val section: String? = null
)