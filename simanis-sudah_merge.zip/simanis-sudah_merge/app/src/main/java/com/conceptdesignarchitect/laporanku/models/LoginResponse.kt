package com.conceptdesignarchitect.laporanku.models

data class LoginResponse(val status:String, val posisi:String, val user: User)
