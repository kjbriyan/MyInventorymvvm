package com.conceptdesignarchitect.laporanku.models

import com.google.gson.annotations.SerializedName

data class KirimResponse(

	@field:SerializedName("status")
	val status: String? = null
)